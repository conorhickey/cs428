#include <stdio.h>
#include "image.h"

/* Read a file in binary format. Return 0 on success, -1 on failure. */
int imbread(FILE *fp, struct image *im)
{
    /* Your code here! */
}

/* Write a file in binary format. Return 0 on success, -1 on failure. */
int imbwrite(FILE *fp, struct image *im)
{
    /* Your code here! */
}

/* Read a file in textual format. Return 0 on success, -1 on failure. */
int imtread(FILE *fp, struct image *im)
{
    /* Your code here! */
}

/* Write a file in textual format. Return 0 on success, -1 on failure. */
int imtwrite(FILE *fp, struct image *im)
{
    /* Your code here! */
}
